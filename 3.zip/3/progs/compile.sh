rm client_1
rm client_2
rm client_3
rm client_4
rm client_5
rm client_6
rm client_7
rm main
unlink fifo1
unlink fifo2
unlink fifo3
unlink fifo4
unlink fifo5
unlink fifo6
unlink fifo7
unlink fifo8
unlink fifo9
g++ main.cpp -o main
g++ client_1.cpp -o client_1
g++ client_2.cpp -o client_2
g++ client_3.cpp -o client_3
g++ client_4.cpp -o client_4
g++ client_5.cpp -o client_5
g++ client_6.cpp -o client_6
g++ client_7.cpp -o client_7

#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo8 "fifo8"
#define fifo9 "fifo9"
#define fifo7 "fifo7"

int main(void)
{
    int pId8;
    int pId9;
    int pId7;

    char buff1[100];
    char buff2[100];
    char buff3[100];
    char merge_buff[300];


    pId8 = open(fifo8, O_RDONLY);
    pId9 = open(fifo9, O_RDONLY);
    pId7 = open(fifo7,O_RDONLY);


    read(pId8, buff1, 99);
    read(pId9, buff2, 99);
    read(pId7,buff3,99);


    strcat(merge_buff, buff1);
    strcat(merge_buff, "+");
    strcat(merge_buff, buff2);
    strcat(merge_buff,"+");
    strcat(merge_buff,buff3);
    strcat(merge_buff, "+client7");

    printf("client7=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    merge_buff);


    close(pId8);
    close(pId9);
    close(pId7);

    exit(0);
}

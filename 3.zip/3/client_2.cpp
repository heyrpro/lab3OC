#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo1 "fifo1"
#define fifo5 "fifo5"
#define fifo4 "fifo4"

int main(void)
{
    int pId1;
    int pId5;
    int pId4;

    char buff[100];

    pId1 = open(fifo1, O_RDONLY);
    pId5 = open(fifo5,O_WRONLY);
    pId4 = open(fifo4, O_WRONLY);

    read(pId1, buff, 99);
    strcat(buff, "+client2");

    write(pId4, buff, 99);
    write(pId5, buff, 99);

    printf("client2=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    buff);


    close(pId1);
    close(pId4);

    exit(0);
}

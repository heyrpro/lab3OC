#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo2 "fifo2"
#define fifo6 "fifo6"

int main(void)
{
    int pId2;
    int pId6;

    char buff[100];

    pId2 = open(fifo2, O_RDONLY);
    pId6 = open(fifo6, O_WRONLY);

    read(pId2, buff, 99);
    strcat(buff, "+client3");

    write(pId6, buff, 99);

    printf("client3=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    buff);


    close(pId2);
    close(pId6);

    exit(0);
}






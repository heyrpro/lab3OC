#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo4 "fifo4"
#define fifo8 "fifo8"

int main(void)
{
    int pId4;
    int pId8;

    char buff[100];

    pId4 = open(fifo4, O_RDONLY);
    pId8 = open(fifo8, O_WRONLY);

    read(pId4, buff, 99);
    strcat(buff, "+client5");

    write(pId8, buff, 99);

    printf("client5=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    buff);


    close(pId4);
    close(pId8);
    exit(0);
}

#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo5 "fifo5"
#define fifo6 "fifo6"
#define fifo9 "fifo9"

int main(void)
{
    int pId5;
    int pId6;
    int pId9;

    char buff1[100];
    char buff2[100];
    char merge_buff[300];

    pId5 = open(fifo5, O_RDONLY);
    pId6 = open(fifo6, O_RDONLY);
    pId9 = open(fifo9,O_WRONLY);

    read(pId5, buff1, 99);
    read(pId6,buff2,99);

    strcat(merge_buff,buff1);
    strcat(merge_buff,"+");
    strcat(merge_buff,buff2);
    strcat(merge_buff, "+client6");

    write(pId9, merge_buff, 99);

    printf("client6=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    merge_buff);


    close(pId5);
    close(pId6);
    close(pId9);
    exit(0);
}

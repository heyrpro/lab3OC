#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo3 "fifo3"
#define fifo7 "fifo7"

int main(void)
{
    int pId3;
    int pId7;

    char buff[100];

    pId3 = open(fifo3, O_RDONLY);
    pId7 = open(fifo7, O_WRONLY);

    read(pId3, buff, 99);
    strcat(buff, "+client4");

    write(pId7, buff, 99);

    printf("client4=%d, ppid=%d, in pipe str=%s\n",
    getpid(), getppid(),
    buff);


    close(pId3);
    close(pId7);
    exit(0);
}

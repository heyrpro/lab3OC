#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define fifo1 "fifo1"
#define fifo2 "fifo2"
#define fifo3 "fifo3"

int main(void)
{
    int pId1;
    int pId2;
    int pId3;
    FILE *fOut;
    char buff[100];
    fOut = fopen("text.txt", "r");
    fgets(buff, 5, fOut);
    strcat(buff, "+client1");

    pId1 = open(fifo1, O_WRONLY);
    pId2 = open(fifo2, O_WRONLY);
    pId3 = open(fifo3,O_WRONLY);

    write(pId1, buff, 99);
    write(pId2, buff, 99);
    write(pId3, buff, 99);

    printf("client1=%d, pPid=%d, in file str=%s\n",
    getpid(), getppid(),
    buff);
    close(pId1);
    close(pId2);
    close(pId3);
    fclose(fOut);
    exit(0);
}






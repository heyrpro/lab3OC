#include <math.h>
#include <iostream>
#include <cstring>
#include <cfenv>

using namespace std;

void runtime__error()
{
    // error handling
    cout << "pow(100000,1000000) = " << pow(100000,1000000) << endl;
    feclearexcept(FE_ALL_EXCEPT);
    if (errno == EDOM)
        cout << "    errno == EDOM: " << strerror(errno) << endl;
    if (errno == ERANGE)
        cout << "    errno == ERANGE: " << strerror(errno) << endl;
    if (fetestexcept(FE_INVALID))
        cout << "    FE_INVALID raised" << endl;
}

int main()
{
    runtime__error();
    return 0;
}

mv main client_1 client_2 client_3 client_4 client_5 client_6 client_7 progs/

#include <iostream>
#include <stdio.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <math.h>
#include <string.h>

#define fifo1 "fifo1"
#define fifo2 "fifo2"
#define fifo3 "fifo3"
#define fifo4 "fifo4"
#define fifo5 "fifo5"
#define fifo6 "fifo6"
#define fifo7 "fifo7"
#define fifo8 "fifo8"
#define fifo9 "fifo9"

using namespace std;

int main(void)
{

    int status;


    //создание каналов

    if(mkfifo(fifo1, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo2, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo3, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo4, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo5, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo6, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo7, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo8, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }
    if(mkfifo(fifo9, 0606) > 0){
        printf("don't create fifo1\n");
        exit(-1);
    }



    //создание процессов

    if(fork() == 0)
        execlp("./client_1", NULL);
    if(fork() == 0)
        execlp("./client_2", NULL);
    if(fork() == 0)
        execlp("./client_3", NULL);
    if(fork() == 0)
        execlp("./client_4", NULL);
    if(fork() == 0)
        execlp("./client_5", NULL);
    if(fork() == 0)
        execlp("./client_6", NULL);
    if(fork() == 0)
        execlp("./client_7", NULL);



    while(wait(&status)>0);


    unlink(fifo1);
    unlink(fifo2);
    unlink(fifo3);
    unlink(fifo4);
    unlink(fifo5);
    unlink(fifo6);
    unlink(fifo7);
    unlink(fifo8);
    unlink(fifo9);


    printf("\n creatorPid= %d\n", getpid());
    exit(0);
}


